import React, { useState } from 'react';
import './style.css';
import {  useNavigate } from "react-router-dom";

function RegistrationPage() {
  const [activeTab, setActiveTab] = useState('sign-up');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
 // const [loggedIn, setLoggedIn] = useState(false);
  //const [confirmPassword, setConfirmPassword] = useState('');

  const handleTabChange = (tabName) => {
    setActiveTab(tabName);
  }

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

 // const handleConfirmPasswordChange = (e) =>{
 //   setConfirmPassword(e.target.value);
 // }

  const handleSignUpSubmit = (event) => {
    event.preventDefault();
    localStorage.setItem("email", email);
    localStorage.setItem("password", password);
   // localStorage.setConfirmPassword("confirmpassword", confirmPassword)
    alert("Registration successful!");
    // perform validation and submit sign-up data
  }

  const navigate = useNavigate();
  //const location = useLocation();

  const handleSignInSubmit = (event) => {
    event.preventDefault();
    const registeredEmail = localStorage.getItem("email");
    const registeredPassword = localStorage.getItem("password");
    if (email === registeredEmail && password === registeredPassword) {
        navigate("Sidebar /");
        //alert("Login successful!");
    } else {
      alert("Invalid email or password");
    }
    // perform validation and submit sign-in data
  }
 // if (location.state?.from) {
  //  navigate(location.state.from);
  //}

  return (
    <div className="registration-page">
      
      <div className="tabs">
        <div className={`tab ${activeTab === 'sign-up' ? 'active' : ''}`} onClick={() => handleTabChange('sign-up')}>Sign up</div>
        <div className={`tab ${activeTab === 'sign-in' ? 'active' : ''}`} onClick={() => handleTabChange('sign-in')}>Sign in</div>
      </div>
      {activeTab === 'sign-up' && (
        <form onSubmit={handleSignUpSubmit}>
          <h2>Create your account.</h2><br></br>
           <p> Build skills for today, tomorrow, and beyond.<br></br>
            Education to future-proof your career.</p>
          <div className="form-group">
            <label htmlFor="email"></label>
            <input type="email" id="email" name="email" placeholder = "Email Address"value={email} onChange={handleEmailChange} required />
          </div>
          <div className="form-group">
            <label htmlFor="password"></label>
            <input type="password" id="password" placeholder= "Password" value={password} onChange={handlePasswordChange} required/>
          </div>
        
          <button type="submit">Create Account</button>
        </form>
      )}
      {activeTab === 'sign-in' && (
        <form onSubmit={handleSignInSubmit}>
            <h2>Sign in to your account.</h2><br></br>
           <p> Build skills for today, tomorrow, and beyond.<br></br>
            Education to future-proof your career.</p>
          <div className="form-group">
            <label htmlFor="email"></label>
            <input type="email" id="email" name="email" placeholder = "Email Address" value={email} onChange={handleEmailChange} required />
          </div>
          <div className="form-group">
            <label htmlFor="password"></label>
            <input type="password" id="password" placeholder= "Password" value={password} onChange={handlePasswordChange}  required/>
          </div>
          <button type="submit">Sign in</button>
        </form>
      )}
    </div>
  );
}

export default RegistrationPage;

import React from "react";
//import Pic from "../../images/Pic.jpg";
export const Chapter2 = () =>{
    return (
        <div className="chapter2">
            <video  src='https://www.youtube.com/embed/dpw9EHDh2bM' width="1500" height ="500" controls autoplay muted>
           </video>
        </div>
    )
}

export const Introduction_to_Android = () =>{
    return (
        <div className="chapter2">
           <video  src='https://www.youtube.com/embed/dpw9EHDh2bM' width="1500" height ="500" controls autoplay muted>
           </video>
        </div>
    )
}

export const Introduction_to_AndroidStudio = () =>{
    return (
        <div className="chapter2">
           <video  src='https://www.youtube.com/embed/dpw9EHDh2bM' width="1500" height ="500" controls autoplay muted>
           </video>
        </div>
    )
}
export const Tools_Required = () =>{
    return (
        <div className="chapter2">
           <img src="Pic1.jpg" alt="Image"></img>
        </div>
    )
}






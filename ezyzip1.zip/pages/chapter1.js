import React from "react";
//import VideoPlayer from "../components/videoPlayer";
import pdfFile from './java_variable_types.pdf';
import { Document,Page } from 'react-pdf/dist/esm/entry.webpack';
export const Chapter1 = () =>{
    return (
        <div className="chapter1">
            <h1>Chapter1</h1>
        </div>
    )
}

export const  GettingReady=()=>{
//const vidRef = useRef(null);

    return (
        <div className="chapter1">   
        <video  src='https://www.youtube.com/embed/dpw9EHDh2bM' width="1500" height ="500" controls autoplay muted>
           
            </video>
        </div>
    )
}

export const Variables = () =>{
    return (
        <div className="chapter1">
            <video  src='https://www.youtube.com/embed/dpw9EHDh2bM' width="1500" height ="500" controls autoplay muted>
           </video>
        </div>
    )
}
export const Comments = () =>{
    return (
        <div className="chapter1">
            <video  src='https://www.youtube.com/embed/dpw9EHDh2bM' width="1500" height ="500" controls autoplay muted>
           </video>
        </div>
    )
}

export const BasicKnowledge = () =>{
    return (
        <div className="chapter1">
           <Document file={pdfFile}>
        <Page pageNumber={1} />
      </Document>
        </div>
    )
}





